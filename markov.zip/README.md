PHP Markov chain text generator
===============================
This is a very simple Markov chain text generator.

More info
---------
* By Hay Kranen: http://www.haykranen.nl/projects/markov
* Fork it on Github: http://github.com/hay/markov